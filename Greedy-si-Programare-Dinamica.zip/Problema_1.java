import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Problema 1
 * @author Dorinela
 *
 */
public class Problema_1 {
	/**
	 * matoda care returneaza maximul dintr-un ArrayList<Integer>
	 * @param v - vectorul din care vrem sa aflam maximul
	 * @return - maximul
	 */
	 public  static  int  maxim(ArrayList<Integer> v)
	 {
		 int  maxim = v.get(0);//initializez maximul cu primul element
		 for(int i=0;i<v.size();i++)//parcurg vectorul
	      {
		   if(maxim<v.get(i))//daca maxim < un elementul de pe pozitia i
		   maxim=v.get(i);//maxim ia valoarea elementului de pe pozitia i
	      }

	 return  maxim;//returnez maxim
	 }
	 
	 @SuppressWarnings("unused")
	 
	 /**
	  * metoda care verifica daca un numar poate fi distanta minima(maxima) ceruta
	  * @param v - vectorul cu distantele stalpilor fata de primul stalp, date luate din fisierul de intrare
	  * @param distanta_posibila - numarul pe care il verific daca poate fi o astfel de distanta ceruta
	  * @param nr_max_stalpi_de_eliminat - numarul maxim de stalpi pe care putem sa-i eliminam, luat din fisier
	  * @return - true(daca numarul poate fi distanta cautata) si false (in caz contrar)
	  */
	 public static boolean aflare_distanta(ArrayList<Integer> v, int distanta_posibila ,int nr_max_stalpi_de_eliminat){
		
         int retin_indice=0;
         int nr=0;
         for(int i=0; i<v.size()-1; ){ //parcurg vectorul cu distantele stalpilor fata de primul
        	 if((v.get(i+1) - v.get(i)) >= distanta_posibila){ //daca distanta dintre doi stalpi consecutivi este >= cu distanta_posibila
        		i++; //atunci distanta pe care am presupus-o eu nu este buna si merg mai departe in parcurgerea vectorului
        	 }
        	else{ // in cazul in care distanta dintre doi stalpi consecutivi este < decat distanta_posibila
        		 retin_indice=i; //retin indicele primului stalp dintre cei doi cu ajutorul carora am facut diferenta
        		 
        		
        		//atata timp cat nu am ajuns la sfarsitul vectorului si distanta dintre elementu al carui indice l-am retinut si 
        		//restul elementelor de la indicele retinut pana la sfarsitul vectorului 
        		//este mai mica decat distanta_posibila atunci am gasit o "distanta posibila"
        		 
        		 while((v.get(i+1) - v.get(retin_indice)) < distanta_posibila && (i<v.size()-2)){ 
        			 nr++; //cresc nr deoarece la sfarsit compar cu nr_max_stalpi_de_eliminat
        			 i++; // parcurg mai departe elementele vectorului
        		 }
        		 //in cazul in care distanta dintre ultimul element al vectorului si penultimul este < decat distanta_posibila 
        		 //atunci am gasit o "distanta posibila"
        		 if((retin_indice == v.size()-2) && (v.get(i+1) - v.get(retin_indice) < distanta_posibila)){
            		 nr++; // si din nou cresc nr;
            		 }
        		 i++;
        	 }
         }
         //in cazul in care am gasit mai multe "distante posibile" decat numarul maxim de stalpi pe care ii pot elimina 
         //atunci distanta pe care eu am presupus-o a fii o "distanta posibila" nu este si returnez FALSE
         //in caz contrar returnez TRUE
         return nr <= nr_max_stalpi_de_eliminat; 
	 }
	
	 /**
	  * metoda main
	  * @param args
	  */
	public static void main(String[] args) {
	
		 ArrayList<Integer> date = new ArrayList<Integer>(); //in date pastrez datele care se gasesc pe prima linie din fisier
		 ArrayList<Integer> distante_fata_de_primul_stalp = new ArrayList<Integer>(); //in distante_fata_de_primul_stalp pastrez distantele fata de primul stalp din fisier incepand cu a doua linie
		 ArrayList<Integer> distante_consecutive = new ArrayList<Integer>();// in distante_consecutive pastrez distantele dintre doi stalpi consecutivi
		 int max = 0; //in max retin maximul din vectorul distante_consecutive
		 int i1 = 0;//in i1 si i2 introduc liniile din fisier convertite la intreg
		 int i2 = 0;
		
			try      
			{
				File dictFile = new File("date.in"); //fisierul din care citesc date
				Scanner reader = new Scanner(dictFile); //variabila pentru citirea din fisier
				@SuppressWarnings("unused")
				String line,line1;//liniile din fisier
				line = reader.nextLine();//citesc prima linie din fisier
				String[] linieFisier = line.split(" "); //separ cu ajutorul lui split si introduc datele in vectorul date
				
				date.add(Integer.parseInt(linieFisier[0]));
				date.add(Integer.parseInt(linieFisier[1]));
				date.add(Integer.parseInt(linieFisier[2]));
				
				line = reader.nextLine(); //citesc a doua linie din fisier
				i1 = Integer.parseInt(line);//convertesc la intreg
				distante_fata_de_primul_stalp.add(i1);//adaug in vector
				while (reader.hasNextLine())//atata timp cat mai am linii in fisier
				{
					line1 = reader.nextLine();//citesc a treia linie din fisier
					i2 = Integer.parseInt(line1);//convertesc la intreg
					
					distante_fata_de_primul_stalp.add(i2);//introduc in vector
					distante_consecutive.add(i2-i1);	//fac distanta intre datele din liniile doi si trei si introduc in vector
					line = line1;//a doua linie devine a treia pentru a face diferenta intre linia trei si patru
					i1 = i2;
					//repet atata timp cat in fisier sunt date
				}
				reader.close();//inchid fisierul din care citesc
			}
			catch(Exception e)
			{
				System.err.println("Error: " + e.getMessage());
			}
			
			int M = date.get(1);//numarul maxim de stalpi pe care pot sa-i elimin
			int L = date.get(2);//lungimea maxima a gardului
			int N = date.get(0);//numarul de stalpi
			
		    max = maxim(distante_consecutive);//calculez maximul din vectorul distante_consecutive cu ajutorul metodei maxim declarata mai sus
			int distanta_gasita = 0; // reprezinta distanta care trebuie calculata
			
			for(int i=1; i<=max; i++) //pentru i de la 1 la max verific daca i poate fi o distanta minima posibila
			{
				if(aflare_distanta(distante_fata_de_primul_stalp, i, M) == false)//apelez functia aflare_distanta pentru fiecare i
					//la returnarea primului false ma opresc
					{
					distanta_gasita = i-1;//rezultatul cautat este ultima valoare de true pana sa intalnesc false deoarece trebuie ca distanta minima dintre oricare doi stalpi consecutivi sa fie maxima
				    break;//am gasit distanta si ies
				    }
			}
			int nr_stalpi_eliminati = 0;//numartul de stalpi pe care i-am eliminat
			
			//pentru a elimina stalpii parcurg vectorul distante_fata_de_primul_stalp
			for(int i=0; i<distante_fata_de_primul_stalp.size()-1;i++){
				//daca distanta dintre doi stalpi consecutivi este mai mica decat distanta_gasita si elementul de la pozitia i+1 este diferit de ultimul stalp pe care nu-l pot elimina
				if((distante_fata_de_primul_stalp.get(i+1) - distante_fata_de_primul_stalp.get(i)) < distanta_gasita && (distante_fata_de_primul_stalp.get(i+1) != L)){
					distante_fata_de_primul_stalp.remove(i+1);//sterg stalpul i+1
					i--;//scad i ca si cum as recalcula distantele dintre stalpi dupa eliminarea stalpului i+1
					nr_stalpi_eliminati++;//numarul de stalpi eliminati creste
				}
			}
			int nr_stalpi_ramasi = N - nr_stalpi_eliminati;//numarul de stalpi care au ramas care sunt numarul total de stalpii - numaru de stalpi pe care i-am eliminat
			//introduc datele in fisierul de iesire
		    BufferedWriter writeToFile=null;
		    try{
		    	writeToFile = new BufferedWriter(new FileWriter("date.out"));
		    	writeToFile.write(Integer.toString(distanta_gasita)+"\n");//pe prima linie a fisierului introduc distanta gasita
		    	writeToFile.write(Integer.toString(nr_stalpi_ramasi) + "\n");//pe a doua linia din fisier, numarul de stalpi care au ramas dupa eliminare
		    	for(int stalp:distante_fata_de_primul_stalp){//pe urmatoarele linii distantele stalpiilor care au mai ramas fata de primul
		    		writeToFile.write(Integer.toString(stalp) + "\n");
		    	}
		    	
		    	writeToFile.close();//inchid fisierul de iesire
		    
		    }catch(IOException ex){
		    	System.out.println(ex);
		    }
	}

}
