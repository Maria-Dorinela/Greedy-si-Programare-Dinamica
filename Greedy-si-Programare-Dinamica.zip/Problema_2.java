import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;


public class Problema_2 {
	static ArrayList<Integer> castiguri = new ArrayList<Integer>();//castigurile pentru cele N sloturi
	static int N=0;//numarul de sloturi
	static int T=0;//numarul sloturilor cat trebuie sa lucreze Georgica
	
	
	public static void main(String[] args) {
		
		//citesc datele din fisier
		try   
		{
			File dictFile = new File("date.in");//fisierul de intrare
			Scanner reader = new Scanner(dictFile);//variabila pentru citirea din fisier
			@SuppressWarnings("unused")
			String line;
			line = reader.nextLine();
			String[] linieFisier = line.split(" "); 
			N = Integer.parseInt(linieFisier[0]);//in N introduc numarul de sloturi
			T = Integer.parseInt(linieFisier[1]);//in T sloturile de timp cat trebuie sa lucreze Georgica
			
			while (reader.hasNextLine())
			{
				line = reader.nextLine();
				castiguri.add(Integer.parseInt(line));//in vectorul castiguri introduc castigurile pentru cele N sloturi
			}
			reader.close();
		}
		catch(Exception e)
		{
			System.err.println("Error: " + e.getMessage());
		}
		
	
		int[][] matrix = new int[N][T];//matricea folosita pentru gasirea castigului maxim care se poate obtine
		int i = 0;
		int j = 0;
		int k = 0;
		
		//prima linie si prima coloana le initializez cu 0
		for(i = 0; i < N; i++)
		{ 
			for(j = 0; j < T; j++)
			{
				matrix[i][0] = 0;
				matrix[0][j] = 0;
			}
		}
		int max = 0;
		
		//calculez castigul maxim folosind o formula de recurenta si programare dinamica
		//castigul maxim obtinut lucrand N sloturi este maximul dintre : suma dintre castigului maxim obtinut la pasul 
		//anterior + castigul slotului i, si maximul de pe coloana anterioara si liniile de la 0 la i
		for(i=1; i<castiguri.size(); i++)
		{
			max = 0;
			for(j=1; j<T; j++)
			{
				for(k = 0; k<=i; k++)
				{
					if(max < matrix[i-k][j-1])
						{
						max = matrix[i-k][j-1]; 
						}
				}
				matrix[i][j] = Math.max(matrix[i-1][j-1] + castiguri.get(i) , max);
			}
		}
		
		//parcurg matricea si aflu castigul maxim
		 int maxim_matrice = 0;
		for(i=0; i<N; i++)
		{
			for(j=0; j<T; j++)
			{
				if(maxim_matrice < matrix[i][j])
				{
					maxim_matrice = matrix[i][j];
				}
			}
			
		}
		
		//introduc castigul maxim obtinut in fisier
		 BufferedWriter writeToFile=null;
		    try{
		    	writeToFile = new BufferedWriter(new FileWriter("date.out"));
		    	writeToFile.write(Integer.toString(maxim_matrice)+"\n");
		    	
		    	writeToFile.close();//inchid fisierul de iesire
		    
		    }catch(IOException ex){
		    	System.out.println(ex);
		    }
		
	}

}
