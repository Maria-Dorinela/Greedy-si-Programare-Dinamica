Sirbu Maria Dorinela
325CB
Tema 1 PA

Tema este facuta in JAVA

Pentru efectuarea primei probleme am realizat:
	metoda "maxim":
		-cu ajutorul acestei metode calculez maximul dintr-un ArrayList<Integer>
	metoda "aflare_distanta":
		-cu ajutorul acesteia verific daca un numar poate fi distanta ceruta in enuntul temei
		-in cod am pus comentarii la fiecare linie de cod pentru ca , cel putin pentru mine, este  mai usor de urmarit
	metoda"main":
		-citesc datele din fisierul de intrare
		-stochez aceste date in ArrayList<Integer>
		-in timp ce citesc datele din fisier calculez si distantele intre doi stalpii consecutivi si retin intr-un ArrayList<Integer>
		-apelez metoda "aflare_distanta" pentru i de la 1 la maximul din vectorul de distante intre stalpii consecutivi
		-ultima valoare de true pana returnarea unui false reprezinta distanta cautata
		-dupa care elimin stalpi si introduc datele cerute in fisierul de iesire
Complexitate:

aflare_distanta(ArrayList<Integer> v, int distanta_posibila ,int nr_max_stalpi_de_eliminat)
for(int i=0; i<v.size()-1;i++) 
int i=0            O(1)
i<v.size()-1    O(1)
i++                  O(1)
O(1) + n*O(1) +n*O(1) = O(n) unde n este dimensiunea -1 a lui v

if((v.get(i+1) - v.get(i)) >= distanta_posibila)        O(1)
{        		
i++;         	O(1): 
} 

v.get(i+1)     O(1)

v.get(i)           O(1)
v.get(i+1) - v.get(i)   O(1)
v.get(i+1) - v.get(i)) >= distanta_posibila   O(1)

O(1) + O(1) + O(1) + O(1) = O(1)

Complexitatea in cazul in care conditia din if e adevarata este O(1)

retin_indice=i     O(1)
while((v.get(i+1) - v.get(retin_indice)) < distanta_posibila && (i<v.size()-2))       O(1)
{ 
        	nr++;     O(1)
        	i++;       O(1)
}

O(1)+O(1)*M+O(1)*M+M*O(1) = O(M)

In cazul in care conditia din if nu e adevarata complexitatea este O(M) depinzand de la caz la caz:


if((retin_indice == v.size()-2) && (v.get(i+1) - v.get(retin_indice) < distanta_posibila))   O(1)
{
            		 nr++;   O(1)
 }
i++ ;  O(1)
Deoarece avem un for care parcurge de la 0 la dimensiunea -1 a lui v si un while care cicleaza in functie de dimensiunea lui M complexitatea finala a functiei aflare_distanta este O(n*M)
max = maxim(distante_consecutive);    O(n)
for(int i=1; i<=max; i++)    O(1)
			{
			if(aflare_distanta(distante_fata_de_primul_stalp, i, M) == false	 O(M*n)
					{
					distanta_gasita = i-1;				    
break;				    
}
			}
}
max*O(1)+max*O(1) = O(max*M*n)

for(int i=0; i<distante_fata_de_primul_stalp.size()-1;i++){          O(1)
if((distante_fata_de_primul_stalp.get(i+1) - distante_fata_de_primul_stalp.get(i)) < distanta_gasita && (distante_fata_de_primul_stalp.get(i+1) != L)){                      O(1)
					distante_fata_de_primul_stalp.remove(i+1);    O(1)
					i--;   O(1)
nr_stalpi_eliminati++;  O(1)
				}
			}
distante_fata_de_primul_stalp.size()-1  are dimensiunea vectorului de stalpi -1 deci 
complexitatea este de n*O(1)+n*O(1)+n*O(1)+n*O(1) = O(n)

In concluzie algoritmul are complexitate O(n*M*max)

Mentionez ca prima problema am trimis-o la timp, in cazul in care se respecta ce s-a discutat pe forum sa nu se scada din implementarea acesteia pentru ca am pus a doua
problema dupa deadline

Problema 2:
-Pentru rezolvarea acestei probleme m-am folosit de programare dinamica (o matrice) care calculeaza castigul maxim pe care poate sa-l obtina Georgica folodind o relatie de recurenta
Complexitate , in cazul cel mai defavorabil, O(n^3).